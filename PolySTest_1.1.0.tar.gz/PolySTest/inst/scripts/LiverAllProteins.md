# Liver data

This data set comes from a proteomics mass spectrometry experiment using isobaric (iTRAQ) labelling for quantifying the underlying peptides. The 
file contains protein quantifications after analysis with Proteome Discoverer. The data in in-house data from an old experiment feeding
rats with different diets (high fat, TTA compound, fish oil and TTA+fish oil. Each of the diets were measured from three rat livers 
(three replicates).

